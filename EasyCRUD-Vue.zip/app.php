
<?php

include "config.php";
$res = array("error" => false);

$action = "read";


if (isset($_GET["action"])) {
    $action = $_GET["action"];
}

if ($action == "read") { $result = $conn->query("SELECT * FROM `categorias`");
        $datos = array();
        while ($row = $result->fetch_assoc()) {
            array_push($datos, $row);
        }

        $res["datos"] = $datos;
    
    
}
// Create form

if ($action == "create") {

    $titulo_categoria= $_POST['titulo_categoria'];
 $img_categoria= $_POST['img_categoria'];


    $result = $conn->query("INSERT INTO categorias(titulo_categoria , img_categoria) VALUES ('$titulo_categoria' , '$img_categoria')");


    if ($result) {
        $res["message"] = "dato agregado exitosamente";
    } else {
        $res["error"] = true;
        $res["message"] = "dato no se agrego exitosamente";
    }

    // $res["datos"] =$datos;
}
// end of create form
// update form

if ($action == "update") {
    $idCat= $_POST['idCat'];
 $titulo_categoria= $_POST['titulo_categoria'];
 $img_categoria= $_POST['img_categoria'];


    $result = $conn->query("UPDATE categorias SET titulo_categoria ='$titulo_categoria' , img_categoria ='$img_categoria' WHERE idCat ='$idCat' ");

    if ($result) {
        $res["message"] = "dato actualizado con éxito";
    } else {
        $res["error"] = true;
        $res["error"] = "dato no se actualizo con éxito";
    }
}

// end of update form

if ($action == "delete") {
    $idCat = $_POST['idCat'];

    $result = $conn->query("DELETE FROM `categorias` WHERE idCat ='$idCat' ");

    if ($result) {
        $res["message"] = "dato borrado exitosamente";
    } else {
        $res["error"] = true;
        $res["message"] = "dato no se borro exitosamente";
    }
    // $res["datos"] =$datos;
}

$conn->close();
header("content-type:application/json");
echo json_encode($res);
die();
?>
