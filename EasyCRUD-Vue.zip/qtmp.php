<?php
//This is temporal file only for add new row
if(isset($_POST['addtable'])){$query = "INSERT INTO table_queries (name_table, col_name, col_type) VALUES
('categorias', 'titulo_categoria', 'varchar')
, ('categorias', 'img_categoria', 'varchar')
";
if($conn->query($query) === TRUE){
echo "Record added successfully";
} else{
                                echo "Error added record: " . $conn->error;
                                }
                                }
?> 
