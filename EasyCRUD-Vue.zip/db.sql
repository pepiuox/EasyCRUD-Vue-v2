-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.6-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.0.0.6047
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Volcando estructura para tabla forever.categorias
CREATE TABLE IF NOT EXISTS `categorias` (
  `idCat` int(11) NOT NULL AUTO_INCREMENT,
  `titulo_categoria` varchar(50) COLLATE utf8_bin NOT NULL,
  `img_categoria` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idCat`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.clientes
CREATE TABLE IF NOT EXISTS `clientes` (
  `idClient` int(11) NOT NULL AUTO_INCREMENT,
  `RUC` char(11) COLLATE utf8_bin NOT NULL DEFAULT '',
  `DNI` char(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `razon_social` varchar(100) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `apellido_paterno` varchar(50) COLLATE utf8_bin NOT NULL,
  `apellido_materno` varchar(50) COLLATE utf8_bin NOT NULL,
  `pais` varchar(50) COLLATE utf8_bin NOT NULL,
  `region_estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `provincia` varchar(50) COLLATE utf8_bin NOT NULL,
  `distrito` varchar(50) COLLATE utf8_bin NOT NULL,
  `direccion` varchar(250) COLLATE utf8_bin NOT NULL,
  `referencia_direccion` varchar(250) COLLATE utf8_bin NOT NULL,
  `tipo_de_cliente` varchar(50) COLLATE utf8_bin NOT NULL,
  `telefono_1` varchar(50) COLLATE utf8_bin NOT NULL,
  `telefono_2` varchar(50) COLLATE utf8_bin NOT NULL,
  `fax` varchar(50) COLLATE utf8_bin NOT NULL,
  `celular` varchar(50) COLLATE utf8_bin NOT NULL,
  `web` varchar(50) COLLATE utf8_bin NOT NULL,
  `email` varchar(50) COLLATE utf8_bin NOT NULL,
  `moneda` varchar(50) COLLATE utf8_bin NOT NULL,
  `limite_de_credito` varchar(50) COLLATE utf8_bin NOT NULL,
  `condicion_de_pago` varchar(50) COLLATE utf8_bin NOT NULL,
  `vendedor` varchar(50) COLLATE utf8_bin NOT NULL,
  `zona` varchar(50) COLLATE utf8_bin NOT NULL,
  `afecta_retencion` varchar(50) COLLATE utf8_bin NOT NULL,
  `estado` varchar(50) COLLATE utf8_bin NOT NULL,
  `usuario` varchar(50) COLLATE utf8_bin NOT NULL,
  `fecha_hora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`idClient`) USING BTREE,
  UNIQUE KEY `DNI` (`DNI`) USING BTREE,
  UNIQUE KEY `usuario` (`usuario`) USING BTREE,
  UNIQUE KEY `RUC` (`RUC`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.cliente_contacto
CREATE TABLE IF NOT EXISTS `cliente_contacto` (
  `idContact` int(11) NOT NULL AUTO_INCREMENT,
  `RUC` char(11) COLLATE utf8_bin NOT NULL DEFAULT '',
  `razon_social` varchar(100) COLLATE utf8_bin NOT NULL,
  `nombre` varchar(50) COLLATE utf8_bin NOT NULL,
  `apellido_paterno` varchar(50) COLLATE utf8_bin NOT NULL,
  `apellido_materno` varchar(50) COLLATE utf8_bin NOT NULL,
  `DNI` char(8) COLLATE utf8_bin NOT NULL DEFAULT '',
  `cargo` varchar(50) COLLATE utf8_bin NOT NULL,
  `telefono` varchar(50) COLLATE utf8_bin NOT NULL,
  `area` varchar(50) COLLATE utf8_bin NOT NULL,
  `email` varchar(50) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idContact`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.cols_set
CREATE TABLE IF NOT EXISTS `cols_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `col_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `type_input` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `list_page` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `add_page` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `update_page` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `view_page` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `delete_page` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `search_text` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `col_set` varchar(150) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.descuentos
CREATE TABLE IF NOT EXISTS `descuentos` (
  `idDesc` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) NOT NULL,
  `descuento` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idDesc`) USING BTREE,
  UNIQUE KEY `producto_id` (`producto_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.entrada_almacen
CREATE TABLE IF NOT EXISTS `entrada_almacen` (
  `idEAlm` int(11) NOT NULL AUTO_INCREMENT,
  `nro_entrada` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `nro_orden` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `doc_ref` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `numero_doc` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT NULL,
  `almacen` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `tipo_movimiento` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `cliente_proveedor` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idEAlm`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.familias
CREATE TABLE IF NOT EXISTS `familias` (
  `idFam` int(11) NOT NULL AUTO_INCREMENT,
  `familia` varchar(100) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idFam`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.grupos
CREATE TABLE IF NOT EXISTS `grupos` (
  `idGrp` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_grupo` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idGrp`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.img_productos
CREATE TABLE IF NOT EXISTS `img_productos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `producto_id` int(11) DEFAULT NULL,
  `imagen_producto` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.marcas
CREATE TABLE IF NOT EXISTS `marcas` (
  `idMarc` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_marca` char(50) COLLATE utf8_bin NOT NULL,
  `familia_producto` char(50) COLLATE utf8_bin NOT NULL,
  `logo_marca` varchar(250) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idMarc`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.productos
CREATE TABLE IF NOT EXISTS `productos` (
  `idPro` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` char(50) NOT NULL,
  `unidad` char(50) NOT NULL,
  `capacidad` char(50) NOT NULL,
  `grupo` int(11) NOT NULL,
  `sub_grupo` int(11) NOT NULL,
  `producto` varchar(350) NOT NULL,
  `puntos` double(11,3) NOT NULL,
  `gerente` double(11,2) NOT NULL,
  `asistente_gerente` double(11,2) NOT NULL,
  `supevisor` double(11,2) NOT NULL,
  `asistente_supervisor` double(11,2) NOT NULL,
  `cliente_novus` double(11,2) NOT NULL,
  `precio_publico` double(11,2) NOT NULL,
  `descripcion` varchar(500) NOT NULL,
  `detalle` text NOT NULL DEFAULT '',
  `uso_sugerido` varchar(500) NOT NULL,
  `contenido` varchar(500) NOT NULL,
  `ingredientes` varchar(500) NOT NULL,
  `imagen` varchar(500) NOT NULL,
  PRIMARY KEY (`idPro`) USING BTREE,
  UNIQUE KEY `codigo` (`codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.productos_forever
CREATE TABLE IF NOT EXISTS `productos_forever` (
  `idPrd` int(11) NOT NULL AUTO_INCREMENT,
  `producto` varchar(150) COLLATE utf8_bin NOT NULL,
  `detalles` varchar(250) COLLATE utf8_bin NOT NULL,
  `marca_id` int(11) NOT NULL DEFAULT 0,
  `categoria_id` int(11) NOT NULL DEFAULT 0,
  `sub_categoria_id` int(11) NOT NULL DEFAULT 0,
  `codigo` char(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `bar_code` char(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `linea` varchar(250) COLLATE utf8_bin NOT NULL,
  `sub_linea` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  `familia_id` int(11) NOT NULL,
  `precio_costo` decimal(10,2) NOT NULL DEFAULT 0.00,
  `precio_publico` decimal(10,2) NOT NULL DEFAULT 0.00,
  `precio` decimal(10,2) NOT NULL DEFAULT 0.00,
  `compra` char(50) COLLATE utf8_bin NOT NULL,
  `venta` char(50) COLLATE utf8_bin NOT NULL,
  `stock` varchar(100) COLLATE utf8_bin NOT NULL,
  `stock_minimo` char(50) COLLATE utf8_bin NOT NULL,
  `stock_maximo` char(50) COLLATE utf8_bin NOT NULL,
  `estado` enum('Disponible','Agotado','Pronto') COLLATE utf8_bin DEFAULT 'Pronto',
  `visible` enum('Disponible','No disponible') COLLATE utf8_bin DEFAULT 'Disponible',
  `unidad_medida` char(50) COLLATE utf8_bin NOT NULL,
  `peso` char(50) COLLATE utf8_bin NOT NULL,
  `volumen` char(50) COLLATE utf8_bin NOT NULL,
  `medidas` char(50) COLLATE utf8_bin NOT NULL,
  `modelo` char(50) COLLATE utf8_bin NOT NULL,
  `garantia` varchar(250) COLLATE utf8_bin NOT NULL DEFAULT '',
  `condiciones` char(50) COLLATE utf8_bin NOT NULL,
  `contenido` char(50) COLLATE utf8_bin NOT NULL,
  `referencia_1` varchar(250) COLLATE utf8_bin NOT NULL,
  `referencia_2` varchar(250) COLLATE utf8_bin NOT NULL,
  `referencia_3` varchar(250) COLLATE utf8_bin NOT NULL,
  `referencia_4` varchar(250) COLLATE utf8_bin NOT NULL,
  `imagen_producto` varchar(250) COLLATE utf8_bin NOT NULL,
  `user_id` char(50) COLLATE utf8_bin DEFAULT NULL,
  `updated` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`idPrd`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.salida_almacen
CREATE TABLE IF NOT EXISTS `salida_almacen` (
  `idSAlm` int(11) NOT NULL AUTO_INCREMENT,
  `nro_salida` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `doc_ref` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `fecha` timestamp NULL DEFAULT NULL,
  `almacen` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `tipo_movimiento` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idSAlm`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.sub_categorias
CREATE TABLE IF NOT EXISTS `sub_categorias` (
  `idSubc` int(11) NOT NULL AUTO_INCREMENT,
  `id_categorias` int(11) NOT NULL,
  `nombre_categoria` varchar(50) COLLATE utf8_bin NOT NULL,
  `img_sub_categoria` varchar(250) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`idSubc`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.sub_grupos
CREATE TABLE IF NOT EXISTS `sub_grupos` (
  `idSug` int(11) NOT NULL AUTO_INCREMENT,
  `grupo_id` int(11) NOT NULL,
  `nombre_sub_grupo` varchar(250) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`idSug`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.table_config
CREATE TABLE IF NOT EXISTS `table_config` (
  `tcon_Id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` text COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`tcon_Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla forever.table_queries
CREATE TABLE IF NOT EXISTS `table_queries` (
  `tque_Id` int(11) NOT NULL AUTO_INCREMENT,
  `name_table` varchar(50) DEFAULT NULL,
  `col_name` varchar(50) DEFAULT NULL,
  `col_type` varchar(50) DEFAULT NULL,
  `input_type` int(11) DEFAULT NULL,
  `joins` varchar(50) DEFAULT NULL,
  `j_table` varchar(50) DEFAULT NULL,
  `j_id` varchar(50) DEFAULT NULL,
  `j_value` varchar(50) DEFAULT NULL,
  `j_as` varchar(50) DEFAULT NULL,
  `query` varchar(250) DEFAULT NULL,
  `jvpos` int(11) DEFAULT NULL,
  PRIMARY KEY (`tque_Id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
